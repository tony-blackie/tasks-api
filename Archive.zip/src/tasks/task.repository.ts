import { Repository, EntityRepository } from 'typeorm';

import { TaskEntity } from './task.entity';

@EntityRepository(TaskEntity)
export class TaskRepository extends Repository<typeof TaskEntity> {}
